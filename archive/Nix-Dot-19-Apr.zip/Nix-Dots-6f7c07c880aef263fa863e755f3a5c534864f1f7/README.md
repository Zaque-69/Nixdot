<p align = "center">
  <img width="400" alt="webui" src="https://github.com/Zaque-69/Nix-Dots/blob/main/logo.png">
</p>

# Nix-Dots
This repo contains a personal Nix configuration, with various AOT themes based on different characters. You can change your theme with a personal command for Fish Shell( "theme1", "theme2", ..., "theme12" ). 
